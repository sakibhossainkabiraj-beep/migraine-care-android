const $=s=>document.querySelector(s), $$=s=>[...document.querySelectorAll(s)];
const state={water:JSON.parse(localStorage.getItem('mc_water')||'[]'),pain:JSON.parse(localStorage.getItem('mc_pain')||'[]'),tasks:JSON.parse(localStorage.getItem('mc_tasks')||'[]'),custom:JSON.parse(localStorage.getItem('mc_custom')||'[]'),selectedPain:null};
const today=()=>new Date().toLocaleDateString();
$('#dateLabel').textContent=new Date().toLocaleDateString();
const mlOptions=[10,20,25,50,100,150,200,250,500,1000];
mlOptions.forEach(n=>{const b=document.createElement('button');b.textContent=n+' ml';b.onclick=()=>addWater(n);$('#waterButtons').append(b)});
function persist(){localStorage.setItem('mc_water',JSON.stringify(state.water));localStorage.setItem('mc_pain',JSON.stringify(state.pain));localStorage.setItem('mc_tasks',JSON.stringify(state.tasks));localStorage.setItem('mc_custom',JSON.stringify(state.custom));}
function addWater(n){state.water.push({ml:n,time:new Date().toLocaleTimeString([],{hour:'2-digit',minute:'2-digit'}),date:today()});persist();renderWater()}
function renderWater(){const entries=state.water.filter(x=>x.date===today());const sum=entries.reduce((a,b)=>a+b.ml,0);$('#waterTotal').textContent=sum+' ml';$('#waterBig').textContent=sum+' ml';$('#waterHistory').innerHTML=entries.slice().reverse().map(x=>`<li><span>💧 ${x.ml} ml</span><span>${x.time}</span></li>`).join('')||'<li>আজ এখনো কোনো রেকর্ড নেই</li>'}
$('#customWater').onsubmit=e=>{e.preventDefault();const n=Number($('#customMl').value);if(n>0&&n<=5000)addWater(n);$('#customMl').value=''};
$('#parseVoice').onclick=()=>{const t=$('#voiceText').value;const m=t.match(/(\d+(?:\.\d+)?)/);if(m){addWater(Number(m[1]));$('#voiceText').value=''}else alert('পরিমাণ লিখুন, যেমন ২৫০ মিলি পানি।')};
$('#voiceBtn').onclick=()=>{const SR=window.SpeechRecognition||window.webkitSpeechRecognition;if(!SR){alert('এই ব্রাউজারে ভয়েস ইনপুট নেই। লেখা দিয়ে যোগ করুন।');return}const r=new SR();r.lang=$('#language').value==='en'?'en-US':$('#language').value==='ar'?'ar-SA':'bn-BD';r.onresult=e=>{$('#voiceText').value=e.results[0][0].transcript};r.start()};
for(let i=0;i<=10;i++){const b=document.createElement('button');b.textContent=i;b.onclick=()=>{state.selectedPain=i;$$('#painScale button').forEach(x=>x.classList.remove('selected'));b.classList.add('selected');$('#painSelected').textContent='ব্যথার মাত্রা: '+i+'/10'};$('#painScale').append(b)}
function renderPain(){const p=state.pain.slice(-5).reverse();$('#painTotal').textContent=state.pain.length?state.pain[state.pain.length-1].level+' / 10':'— / 10';$('#painHistory').innerHTML=p.map(x=>`<li><span>${x.level}/10 — ${escapeHtml(x.note||'কোনো নোট নেই')}</span><small>${x.time}</small></li>`).join('')||'<li>এখনো কোনো রেকর্ড নেই</li>'}
$('#savePain').onclick=()=>{if(state.selectedPain===null){alert('০ থেকে ১০-এর মধ্যে একটি মাত্রা বেছে নিন।');return}const level=state.selectedPain;state.pain.push({level,note:$('#symptoms').value,time:new Date().toLocaleString(),date:today()});persist();renderPain();const box=$('#painAdvice');box.classList.remove('hidden');box.innerHTML=level>=8?'<b>উচ্চ তীব্রতা</b><p>আপনার স্বাভাবিক পরিকল্পনা অনুসরণ করুন এবং দ্রুত চিকিৎসকের পরামর্শ নিন, বিশেষত ব্যথা নতুন/অস্বাভাবিক হলে। জরুরি সতর্ক লক্ষণ থাকলে জরুরি চিকিৎসা নিন।</p>':level>=5?'<b>মাঝারি থেকে বেশি ব্যথা</b><p>শান্ত পরিবেশে বিশ্রাম নিন, পানি পান করুন, উপসর্গ লিখে রাখুন এবং চিকিৎসকের দেওয়া পরিকল্পনা অনুসরণ করুন।</p>':'<b>নিজের যত্ন চালিয়ে যান</b><p>নিয়মিত খাবার, ঘুম, তরল ও ট্রিগার ডায়েরি বজায় রাখুন। ব্যথা বাড়লে বা বারবার হলে চিকিৎসকের সঙ্গে কথা বলুন।</p>'};
$$('.tab').forEach(b=>b.onclick=()=>{$$('.tab').forEach(x=>x.classList.toggle('active',x===b));$$('.panel[id]').forEach(p=>p.classList.toggle('hidden',p.id!==b.dataset.tab))});
function escapeHtml(s){return String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]))}
$('#customTask').onsubmit=e=>{e.preventDefault();state.custom.push({text:$('#taskText').value,time:$('#taskTime').value});persist();renderTasks();$('#taskText').value=''};
function renderTasks(){$('#taskList').innerHTML=state.custom.map(x=>`<li><span>${escapeHtml(x.text)}</span><b>${x.time}</b></li>`).join('')||'<li>নিজের কাজ যোগ করুন</li>'}
$('#saveRoutine').onclick=()=>{const vals=$$('.routineitem').map(r=>({task:r.querySelector('[data-task]').dataset.task,checked:r.querySelector('input[type=checkbox]').checked,time:r.querySelector('input[type=time]').value}));localStorage.setItem('mc_routine',JSON.stringify(vals));$('#reminderStatus').textContent='রুটিন এই ডিভাইসে সংরক্ষিত হয়েছে।'}
$('#enableNotifications').onclick=async()=>{if(!('Notification'in window)){alert('এই ব্রাউজারে নোটিফিকেশন সমর্থিত নয়।');return}const p=await Notification.requestPermission();$('#reminderStatus').textContent=p==='granted'?'নোটিফিকেশন অনুমতি দেওয়া হয়েছে। নির্ভরযোগ্য নির্দিষ্ট-সময়ের অ্যালার্মের জন্য ইনস্টল করা অ্যাপ/ব্যাকএন্ড দরকার।':'নোটিফিকেশন অনুমতি দেওয়া হয়নি।'};
$('#saveProfile').onclick=()=>{localStorage.setItem('mc_profile',JSON.stringify({name:$('#displayName').value,email:$('#email').value,gender:$('#gender').value}));alert('প্রোফাইল এই ডিভাইসে সংরক্ষিত হয়েছে।')};
$('#avatar').onchange=e=>{const f=e.target.files[0];if(f){const r=new FileReader();r.onload=()=>{$('#avatarPreview').src=r.result;$('#avatarPreview').classList.remove('hidden');localStorage.setItem('mc_avatar',r.result)};r.readAsDataURL(f)}};
$('#setOwnerPass').onclick=()=>{const p=$('#ownerPass').value;if(p.length<8){alert('কমপক্ষে ৮ অক্ষরের পাসওয়ার্ড দিন।');return}localStorage.setItem('mc_demo_owner_pass',p);localStorage.setItem('mc_owner_name',$('#ownerName').value);alert('ডেমো পাসওয়ার্ড সেট হয়েছে। এটি নিরাপদ সার্ভার-সাইড লগইন নয়।')};
$('#adminEnter').onclick=()=>{if($('#adminLogin').value&&$('#adminLogin').value===localStorage.getItem('mc_demo_owner_pass'))$('#adminPanel').classList.remove('hidden');else alert('পাসওয়ার্ড মেলেনি।')};
$('#saveAdminNotes').onclick=()=>{localStorage.setItem('mc_admin_notes',$('#adminNotes').value);alert('নোট সংরক্ষিত হয়েছে।')};
const langs={
bn:{home:'হোম',water:'পানি',pain:'ব্যথা',routine:'রুটিন',profile:'প্রোফাইল'},
en:{home:'Home',water:'Water',pain:'Pain',routine:'Routine',profile:'Profile'},
ar:{home:'الرئيسية',water:'الماء',pain:'الألم',routine:'الروتين',profile:'الملف الشخصي'}
};
$('#language').onchange=()=>{const l=langs[$('#language').value];$$('[data-i18n]').forEach(e=>e.textContent=l[e.dataset.i18n]);document.documentElement.dir=$('#language').value==='ar'?'rtl':'ltr';localStorage.setItem('mc_lang',$('#language').value)};
const savedProfile=JSON.parse(localStorage.getItem('mc_profile')||'null');if(savedProfile){$('#displayName').value=savedProfile.name||'';$('#email').value=savedProfile.email||'';$('#gender').value=savedProfile.gender||'prefer'}
if(localStorage.getItem('mc_avatar')){$('#avatarPreview').src=localStorage.getItem('mc_avatar');$('#avatarPreview').classList.remove('hidden')}
$('#ownerName').value=localStorage.getItem('mc_owner_name')||'মোঃ সাকিব হোসাইন নিরব';$('#adminNotes').value=localStorage.getItem('mc_admin_notes')||'';
const savedRoutine=JSON.parse(localStorage.getItem('mc_routine')||'[]');savedRoutine.forEach(x=>{const r=$(`[data-task="${x.task}"]`);if(r){r.checked=x.checked;r.closest('.routineitem').querySelector('input[type=time]').value=x.time}});
if(localStorage.getItem('mc_lang'))$('#language').value=localStorage.getItem('mc_lang');
renderWater();renderPain();renderTasks();
if('serviceWorker'in navigator && location.protocol.startsWith('http'))navigator.serviceWorker.register('./sw.js').catch(()=>{});
